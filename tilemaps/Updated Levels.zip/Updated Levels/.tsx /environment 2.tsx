<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.2" name="environment 2" tilewidth="8" tileheight="8" spacing="5" tilecount="25" columns="5">
 <image source="../environment 2.png" width="64" height="64"/>
</tileset>
