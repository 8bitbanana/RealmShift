<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.3" name="Desert tree (3)" tilewidth="8" tileheight="8" spacing="5" tilecount="144" columns="12">
 <image source="../../../../../Downloads/Desert tree (3).png" width="160" height="160"/>
</tileset>
