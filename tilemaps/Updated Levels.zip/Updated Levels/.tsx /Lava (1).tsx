<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.3" name="Lava (1)" tilewidth="16" tileheight="16" spacing="5" tilecount="1" columns="1">
 <image source="../../../../../Downloads/Lava (1).png" width="16" height="16"/>
</tileset>
