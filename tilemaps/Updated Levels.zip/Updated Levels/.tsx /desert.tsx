<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.3" name="desert" tilewidth="8" tileheight="8" spacing="5" tilecount="100" columns="10">
 <image source="../desert.png" width="128" height="128"/>
</tileset>
