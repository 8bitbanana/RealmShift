<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.3" name="Desert red rock" tilewidth="8" tileheight="8" tilecount="400" columns="20">
 <image source="../../../../../Downloads/Desert red rock.png" width="160" height="160"/>
</tileset>
